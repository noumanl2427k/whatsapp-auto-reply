WhatsApp Auto Reply - Android APK Build Guide

Important:
Is environment mein Android SDK/Gradle installed nahi tha, is liye yahan se direct APK compile nahi ho saka.
Maine project ko clean Android project format mein prepare kar diya hai.

Build karne ka easiest tareeqa:

1. Android Studio install/open karein.
2. Is folder ko Android Studio mein Open karein.
3. Android Studio Gradle sync karega. Internet required ho sakta hai dependencies download ke liye.
4. Agar Gradle wrapper missing ka issue aaye, Android Studio se Gradle sync/reload karein ya terminal mein installed Gradle se wrapper generate karein.
5. APK banane ke liye:
   Build > Build Bundle(s) / APK(s) > Build APK(s)

Terminal command, agar Gradle/SDK installed ho:
   gradle assembleDebug

APK usually yahan milega:
   app/build/outputs/apk/debug/app-debug.apk

App use karne ka tareeqa:
1. APK install karein.
2. App open karein.
3. Auto reply message likhein aur Save karein.
4. Enable Notification Access button press karein.
5. Android settings mein WhatsApp Auto Reply Listener ko allow karein.
6. App mein wapas aake Auto Reply ON karein.
7. WhatsApp/WhatsApp Business message notification aane par same saved reply send hoga.

Limitations:
- App sirf WhatsApp notification ke Reply action se reply karegi.
- Agar notification nahi aata, reply nahi hoga.
- Agar chat already open ho, notification generate nahi ho sakta.
- Battery optimization service ko stop kar sakti hai.
